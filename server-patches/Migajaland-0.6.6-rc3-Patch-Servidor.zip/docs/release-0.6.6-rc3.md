# Migajaland 0.6.6-rc3 — balance integral de Upgrader

- Sustituye el balance genérico de Upgrader por valores basados en progresión, familia, categoría y ranura.
- Audita los 7.222 objetos registrados por el modpack.
- Da cobertura a las 673 armas, herramientas, armaduras y accesorios permitidos.
- Divide Armageddon en 14 etapas y diferencia materiales, armaduras, accesorios, armas y herramientas.
- Balancea Armor of the Ages, RPG Series, Mowzie's Mobs y Too Many Bows.
- Añade precios a los cinco accesorios de combate de Too Many Bows y a Cursed Stone.
- Bloquea objetos creativos, técnicos, contenedores con datos y elementos capaces de saltarse la progresión.
- Mantiene el límite de 20 intentos cada 10 minutos y el 10 % de pérdida económica media.

La candidata compiló con Java 21, cargó el modpack completo en NeoForge 21.1.229, alcanzó `Done` y se apagó limpiamente. Migajaland Core conserva `MATCH_VERSION`: cliente y servidor deben usar esta misma versión.
