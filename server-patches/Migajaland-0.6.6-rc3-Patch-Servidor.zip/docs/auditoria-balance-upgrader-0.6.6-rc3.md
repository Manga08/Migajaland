# Auditoría integral de Upgrader Items — 0.6.6-rc3

## Problema confirmado

Upgrader 1.2.0 calcula correctamente muchas recetas, pero para objetos sin una receta resoluble termina dependiendo casi solo de la rareza declarada. En Migajaland eso no representa su poder real: numerosos objetos de Armageddon son `COMMON`, aunque procedan de jefes avanzados, y algunos accesorios de Too Many Bows ni siquiera estaban incluidos en el primer balance.

La primera corrección por espacio de nombres tampoco era válida. Ponía un suelo parecido a una herramienta de piedra, una pechera avanzada y un arma de jefe siempre que compartieran rareza. Se sustituyó por una política basada en progresión, familia, tipo de objeto y ranura.

## Cobertura medida en el juego

El servidor aislado cargó el registro real completo de Migajaland y auditó 7.222 objetos:

- 679 objetos con datos, creativos o de progresión quedaron bloqueados.
- Las 673 armas, herramientas, armaduras y accesorios permitidos tienen una regla de valor; ninguno usa únicamente el valor genérico de rareza.
- Armageddon: 477 objetos revisados, 106 bloqueados, 321 con precio de progresión y 50 bloques/materiales comunes que conservan su receta o valor normal.
- Too Many Bows: sus 34 arcos, cinco accesorios de combate y la piedra maldita tienen valores manuales. Los otros tres materiales fabricables conservan su coste de receta.
- Armor of the Ages: 41 piezas permitidas, repartidas por conjunto y ranura.
- RPG Series: 225 piezas entre Archers, Arsenal, Paladins, Rogues y Wizards, repartidas por las etiquetas oficiales de tier 0–6.
- Mowzie's Mobs: armas, máscaras, equipo de geomante y botín de jefes con valores curados individualmente.

## Escala de Armageddon

Se usan 14 etapas con bases desde 6.000 hasta 1.000.000. Después se aplica un factor por categoría: los materiales cuestan menos que el equipo terminado; pechera, pantalones, casco y botas tienen costes distintos; los accesorios consideran su rareza; y las armas se separan por tipo.

| Referencia | Valor corregido |
|---|---:|
| Lucky Beetle | 18.000 |
| Pechera gilded | 8.800 |
| Pechera elvenita | 99.000 |
| Pechera voiderita | 143.000 |
| Pechera calamitosa | 275.000 |
| Pechera sangrienta | 385.000 |
| Pechera helionita | 660.000 |
| Anathema Gauntlet | 200.000 |
| Helionite Throwing Dagger | 270.000 |
| The Excidium | 1.000.000 |
| Prism of Realms | 1.000.000 |

`Vitalis Pearl` queda en 60.000 porque consume la lágrima de Khyros. `Prism of Realms` queda en 1.000.000 porque además consume Eclipsium final y otorga un objeto irrompible con curación, ataque de área y teletransporte.

También se detectaron dos accesorios de Armageddon sin la etiqueta Curios. El propio mod los describe como `Creative Only`; ahora están bloqueados, igual que el proyectil interno `fire_spark_item` y el pergamino con identificador mal escrito `wither_lore_swroll`.

## Arcos y accesorios

Too Many Bows conserva una escala de 6.000 a 1.000.000 según la etapa de jefe. Se añadieron los cinco accesorios que faltaban:

| Objeto | Valor |
|---|---:|
| Fletcher's Talisman | 8.000 |
| Sharpshot Ring | 25.000 |
| Dead Eye's Pendant | 60.000 |
| Wind Glove | 130.000 |
| Stormbound Signet | 180.000 |
| Cursed Stone | 150.000 |

La piedra maldita era especialmente peligrosa: costaba solo 2.500 y sirve para fabricar el Necro Flame Bow de 600.000.

## Objetos que no se pueden obtener con Upgrader

Se bloquean bolsas de jefes, reliquias de historia, invocadores, plantillas de progresión, ojos de End Remastered, tarjetas y máquinas de Easy Mob Farm, mochilas/almacenamientos con contenido, bebés y registros de MCA, libros y pergaminos con datos, pinturas personalizadas y otros contenedores cuyo valor no representa su contenido.

## Probabilidades de referencia

La fórmula sigue siendo `0,9 × valor entregado / valor solicitado`, con máximo de 90 %. Por ejemplo:

| Objetivo | Con 1 diamante | Con 1 bloque de netherita |
|---|---:|---:|
| Lucky Beetle (18.000) | 2 % | 90 % |
| Pechera elvenita (99.000) | 0,364 % | 41,236 % |
| Anathema Gauntlet (200.000) | 0,18 % | 20,412 % |
| Pechera sangrienta (385.000) | 0,094 % | 10,604 % |
| Pechera helionita (660.000) | 0,055 % | 6,185 % |
| The Excidium / Prism of Realms (1.000.000) | 0,036 % | 4,082 % |

El sistema mantiene una pérdida económica media del 10 % y el límite de 20 intentos cada 10 minutos. Un objeto avanzado ya no cuesta lo mismo que equipo inicial, pero continúa siendo obtenible si se arriesga una ofrenda acorde.

## Verificación técnica

- Compilación con Java 21: correcta.
- Arranque dedicado aislado con NeoForge 21.1.229 y el modpack completo: correcto.
- Registro auditado: 7.222 objetos.
- Excepciones de Migajaland Core o del mixin de Upgrader: ninguna.
- Servidor de prueba: alcanzó `Done` y se apagó guardando las tres dimensiones.
- El servidor real y los datos de los jugadores no se modificaron durante esta auditoría.
