# Auditoría de costes reforzados de Upgrader — 0.6.6-rc4

## Decisión

El balance de `0.6.6-rc3` identificaba correctamente las categorías y etapas, pero todavía hacía demasiado atractiva la apuesta frente a conseguir el objeto mediante exploración, fabricación o jefes. Esta revisión conserva aquella clasificación y aplica dos escalas adicionales:

- equipo de progresión temprana o media: coste base multiplicado por 2;
- equipo avanzado o final, cuyo valor base auditado sea de 90.000 o más: coste base multiplicado por 3.

Los bloques, comida, decoración, materiales ordinarios y equipo inicial fabricable mantienen el valor de su receta. Las exclusiones de objetos creativos, técnicos, contenedores con datos, bolsas e invocadores tampoco cambian.

## Referencias verificadas en el registro real

| Objeto | Valor anterior | Valor 0.6.6-rc4 |
|---|---:|---:|
| Lucky Beetle | 18.000 | 36.000 |
| Pechera elvenita | 99.000 | 297.000 |
| Anathema Gauntlet | 200.000 | 600.000 |
| Pechera sangrienta | 385.000 | 1.155.000 |
| Pechera helionita | 660.000 | 1.980.000 |
| The Excidium | 1.000.000 | 3.000.000 |
| Prism of Realms | 1.000.000 | 3.000.000 |
| Dusk Reaper | 1.000.000 | 3.000.000 |

La fórmula continúa siendo `0,9 × valor entregado / valor solicitado`, con máximo de 90 %. Las probabilidades resultantes son:

| Objetivo | Con 1 diamante | Con 1 bloque de netherita |
|---|---:|---:|
| Lucky Beetle | 1 % | 90 % |
| Pechera elvenita | 0,1212 % | 13,745 % |
| Anathema Gauntlet | 0,06 % | 6,804 % |
| Pechera sangrienta | 0,0312 % | 3,535 % |
| Pechera helionita | 0,0182 % | 2,062 % |
| The Excidium / Prism of Realms | 0,012 % | 1,361 % |

## Cobertura y prueba

- NeoForge inició correctamente con Migajaland Core `0.6.6-rc4`.
- Se auditaron 7.222 objetos del registro real.
- 679 objetos protegidos permanecen bloqueados.
- 766 objetos reciben el nuevo coste reforzado; 335 pertenecen a Armageddon.
- Armageddon, Too Many Bows, Armor of the Ages, RPG Series, Mowzie's Mobs y el equipo de combate genérico quedaron cubiertos.
- El servidor aislado alcanzó `Done`, cargó las 151 misiones y generó el informe sin excepciones de Migajaland Core ni del mixin de Upgrader.

