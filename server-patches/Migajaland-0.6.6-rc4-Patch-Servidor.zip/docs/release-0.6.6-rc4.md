# Migajaland 0.6.6-rc4 — costes reforzados de Upgrader

- Duplica el coste del equipo de progresión temprana o media.
- Triplica el coste del equipo avanzado o final.
- Mantiene intactos los valores normales de recetas, bloques, comida, decoración y equipo inicial.
- Actualiza la guía integrada para explicar la nueva escala.
- Conserva las protecciones, el límite de 20 intentos por 10 minutos y la pérdida total de la apuesta al fallar.

La prueba dedicada auditó 7.222 objetos y arrancó NeoForge, Migajaland Core, Upgrader y las 151 misiones correctamente.
